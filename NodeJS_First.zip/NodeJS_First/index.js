import connectDB from "./src/db/index.js";
import { app } from "./src/app.js";
import dotenv from 'dotenv'


dotenv.config({
    path : './.env'
})


connectDB().then(() => 
    app.listen(process.env.PORT || 8000, () => {
        console.log(`Server started at ${process.env.PORT}`)
    })
).catch(error => {
    console.log("MongoDB Connection Failes", error)
})

