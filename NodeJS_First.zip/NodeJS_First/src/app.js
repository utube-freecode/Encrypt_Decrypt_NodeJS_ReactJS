import express, { urlencoded } from 'express'
import cors from 'cors'
import bodyParser from 'body-parser'

const app = express()

app.use(cors())

app.use(express.json({limit : '16kb'}))

// Middleware
app.use(bodyParser.json());

app.use(urlencoded({extended : true, limit : '16kb'}))

app.get("/", (req, res, next) => {
    res.status(200).json("First MongoDB Connected")
})

import userRouter from './routes/user.routes.js'
import moviesRouter from './routes/movies.routes.js'
import encryptData from './utils/encryptData.js'
import decryptData from './utils/decryptData.js'

app.use("/user", userRouter)                // http://localhost:8000/user/register

app.use("/movies", moviesRouter)

app.post('/encryptdata', (req, res, next) => {
    const {data} = req.body
    console.log(data, "data")

    const encrypted = encryptData(data)
    res.status(200).json(encrypted)
})

app.post('/decryptdata', (req, res, next) => {
    const {data} = req.body
    console.log(data, "data")

    const decrypted = decryptData(data)
    res.status(200).json(decrypted)
})

export {app}