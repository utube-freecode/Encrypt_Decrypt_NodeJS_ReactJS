import mongoose, { Schema } from "mongoose";


const moviesSchema = new mongoose.Schema({
    movieName : {
        type : String,
        required : true,
        trim : true
    },
    user : {
        type : Schema.Types.ObjectId,
        ref : "User"
    }
}, {
    timestamps : true
})

export const Movies = mongoose.model("Movies", moviesSchema)