import { User } from "../models/user.models.js";
import bcrypt from 'bcrypt'
import createSecretToken from "../utils/generateToken.js";
import encryptData from "../utils/encryptData.js";
import decryptData from "../utils/decryptData.js";


// registerUser
const registerUser = async(req, res, next) => {

    const {username, email, fullName, password} = req.body
    console.log(username, "username")
    console.log(email, "email")

    // Validation for All required fields
    if([username, fullName, email, password].some((field) => 
        field?.trim() === "")
    ){
        return res.status(400).json({
            message : "All fields are required"
        })
    }

    // Validation for User already exist
    const existUser = await User.findOne({
        $or : [{username} ,{email}]
    })
    console.log(existUser, "existUser")

    if(existUser){
        return res.status(409).json({
            message : "User already exist"
        })
    }

    // encrypt password
    const salt = 10
    const hashedPassword = await bcrypt.hash(password, salt)

    // Create User
    const user = await User.create({
        fullName : fullName,
        email : email,
        username : username,
        password : hashedPassword
    })
    console.log(user, "user")

    const createdUser = await User.findById(user._id).select("-password")
    console.log(createdUser, "createdUser")

    if(!createdUser){
        return res.status(500).json({
            message : "Something went wrong while registering user"
        })
    }

    // creating token
    const token = createSecretToken({
        username : createdUser?.username
    });

    // encryting data
    const encryptCreatedUser = encryptData(createdUser)
    console.log(encryptCreatedUser, "encryptCreatedUser")

    // Response
    return res.status(201).cookie("token", token, {
        path: "/", 
        expires: new Date(Date.now() + 86400000), // Cookie expires in 1 day
        secure: true, 
        httpOnly: true, 
        sameSite: "None",
      }).json({
        message : "User Registered Successfully",
        data : encryptCreatedUser
    })

}


// getUsers
const getUsers = async(req, res, next) => {
    const users = await User.find().select("-password")
    console.log(users)

    if(!users){
        return res.status(400).json({
            message : "Users doesnt exist"
        })
    }

    // encryting data
    const encryptUsers = encryptData(users)
    console.log(encryptUsers, "encryptUsers")

    return res.status(200).json({
        message : "User fetched successfully",
        data : encryptUsers
    })
}


// loginUser
const loginUser = async(req, res, next) => {

    try {
        const {cipherData} = req.body;
        console.log(cipherData, "cipherText");

        // if (typeof data !== "string" || !data.trim()) {
        //     throw new Error("Invalid ciphertext");
        // }

        if (!cipherData) {
            return res.status(400).json({ message: "Missing data" });
        }
        

        // Decrypt the data
        const decrypted = await decryptData(cipherData);
        console.log(decrypted, "decrypted");

        // Destructure the decrypted data
        const { username, password } = decrypted;
        console.log(username, 'username');

        if([username, password].some((field) => field?.trim() === "")){
            return res.status(400).json({
                message : "All Fields are required"
            })
        }

        const user = await User.findOne({username})
        console.log(user, 'user')

        if(!user){
            return res.status(404).json({
                message : "User does not exist"
            })
        }

        // comparing password using bcrypt
        const isPasswordCorrect = await bcrypt.compare(password, user.password)

        if(!isPasswordCorrect){
            return res.status(401).json({
                message : "Invalid Password"
            })
        }

        const loggedInUser = await User.findById(user._id).select("-password")

        // creating token
        const token = createSecretToken({
            username : loggedInUser?.username
        })
        console.log(token, "token")

        // encryting data
        const encryptLoggedInUser = await encryptData(loggedInUser)
        console.log(encryptLoggedInUser, "encryptLoggedInUser")
        

        return res.status(200).cookie("token", token, {
            path: "/", 
            expires: new Date(Date.now() + 86400000), // Cookie expires in 1 day
            secure: true, 
            httpOnly: true, 
            sameSite: "None",
        }).json({
            message : "Login Successful",
            data : encryptLoggedInUser,
        })
        
    } catch (error) {
        console.log(error)
    }

    

}


// updatePassword
const updatePassword = async(req, res,next) => {

    const {email, oldPassword, newPassword} = req.body
    console.log(email, "email")


    if([email, oldPassword, newPassword].some((field) => field?.trim() === "")){
        return res.status(400).json({
            message : "All fields are required"
        })
    }

    const user = await User.findOne({email})
    console.log(user)

    if(!user){
        return res.status(404).json({
            message : "User does not exist"
        })
    }

    const isOldPasswordCorrect = await bcrypt.compare(oldPassword, user.password)

    if(!isOldPasswordCorrect){
        return res.status(401).json({
            message : "Invalid Old Password"
        })
    }

    const isNewPasswordValid = await bcrypt.compare(newPassword, user.password)

    if(isNewPasswordValid){
        return res.status(409).json({
            message : "New Password can not be same as old one"
        })
    }

    // encrypt password
    const salt = 10
    const hashedPassword = await bcrypt.hash(newPassword, salt)

    const updateUser = await User.findByIdAndUpdate(user._id, { password : hashedPassword})
    console.log(updateUser, "updateUser")

    if(!updateUser){
        return res.status(500).json({
            message : "Something went wrong while updating password"
        })
    }

    return res.status(201).json({
        message : "Password updated successfully"
    })

}


// deleteAccount
const deleteAccount = async(req, res, next) => {

    const {email, password} = req.body
    console.log(email, "email")

    if([email, password].some((field) => field.trim() === "")){
        return res.status(400).json({
            message : "All fields are required"
        })
    }

    const user = await User.findOne({email})
    console.log(user, "user")

    if(!user){
        return res.status(404).json({
            message : "User does not exist"
        })
    }

    // comparing password using bcrypt
    const isPasswordCorrect = await bcrypt.compare(password, user.password)

    if(!isPasswordCorrect){
        return res.status(401).json({
            message : "Invalid Password"
        })
    }

    const deletedDocument = await User.findByIdAndDelete(user._id)

    if(!deletedDocument){
        return res.status(500).json({
            message : "Something went wrong while deleting account"
        })
    }

    return res.status(200).json({
        message : "Account deleted successfully"
    })

}



export {registerUser, getUsers, loginUser, updatePassword, deleteAccount}