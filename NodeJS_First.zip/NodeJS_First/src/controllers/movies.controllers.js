import { Movies } from "../models/movies.models.js";
import decryptData from "../utils/decryptData.js";
import encryptData from "../utils/encryptData.js";


// addMovies
const addMovies = async(req, res, next) => {

    const {movieName, user} = req.body
    console.log(movieName, "movieName")
    console.log(user, "user")

    if([user, movieName].some((field) => field.trim() === "")){
        return res.status(400).json({
            message : "All fields are required"
        })
    }

    const existMovie = await Movies.findOne({
        $and : [{movieName}, {user}]
    })
    console.log(existMovie, "existMovie")

    if(existMovie){
        return res.status(409).json({
            message : "Movie with this user already exist"
        })
    }

    const movie = await Movies.create({
        movieName : movieName,
        user : user
    })
    console.log(movie, "movie")

    const createdMovie = await Movies.findById(movie._id)

    if(!createdMovie){
        return res.status(500).json({
            message : "Something went wrong while adding movie"
        })
    }

    return res.status(201).json({
        message : "Movie added successfully",
        data : createdMovie
    })

}


// getMovies
const getMovies = async(req, res, next) => {

    const {cipherData} = req.body;
    console.log(cipherData, "cipherText");

    if (!cipherData) {
        return res.status(400).json({ message: "Missing data" });
    }
        
    // Decrypt the data
    const decrypted = await decryptData(cipherData);
    console.log(decrypted, "decrypted");

    const {_id} = decrypted
    console.log(_id, "_id")

    
    if(!_id){
        return res.status(400).json({
            message : "All fields are required"
        })
    }

    const movies = await Movies.find({user : _id})
    console.log(movies, "movies")

    if(!movies){
        return res.status(404).json({
            message : "Movies not found"
        })
    }

    // encryting data
    const encryptedMovies = await encryptData(movies)
    console.log(encryptedMovies, "encryptedMovies")

    if(!encryptedMovies){
        return res.status(500).json({
            message : "Something went wrong"
        })
    }

    return res.status(200).json({
        message : "Movies fetched successfully",
        data : encryptedMovies
    })
}


// getUsersFromMovie
const getUsersFromMovie = async(req, res, next) => {

    const {movieName} = req.body
    console.log(movieName, "movieName")

    if(movieName.trim() === ""){
        return res.status(400).json({
            message : "All fields are required"
        })
    }

    const users = await Movies.aggregate([
        {
            $match : {
                movieName : movieName
            },
        },
        {
            $lookup : {
                from : "users",
                localField : "user",
                foreignField : "_id",
                as : "userDetails"
            },
        },
        {
            $unwind : {
                path : "$userDetails"
            }
        },
        {
            $project : {
                userDetails : 1
            }
        }
    ])

    console.log(users, "users")

    if(!users){
        return res.status(404).json({
            message : "Users not found"
        })
    }

    return res.status(200).json({
        message : "Users found",
        data : users
    })

}


// insertManyMovies
const insertManyMovies = async(req, res, next) => {

    const {movieNames} = req.body
    console.log(movieNames, "movieNames")

    if(!movieNames){
        return res.status(400).json({
            message : "Movie Names are required"
        })
    }

    //TODO: add Validation for already exist movie and user

    const movies = await Movies.insertMany(movieNames) 
    console.log(movies, "movies")   

    if(!movies){
        return res.status(500).json({
            message : "Something went wrong while inserting movies"
        })
    }

    return res.status(201).json({
        message : "Movie names inserted successfully",
        data : movies
    })

}


export {addMovies, getMovies, getUsersFromMovie, insertManyMovies}