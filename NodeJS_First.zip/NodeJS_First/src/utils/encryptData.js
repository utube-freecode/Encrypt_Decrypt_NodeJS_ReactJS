import CryptoJS from "crypto-js";

function encryptData(data) {
    // Convert data to a string if it's an object
    const text = typeof data === "string" ? data : JSON.stringify(data);

    // Encrypt the data
    const encrypted = CryptoJS.AES.encrypt(text, process.env.CRYPTO_KEY).toString();

    return encrypted;
}


export default encryptData



// const encryptData = (pwd) => {
//     const key = CryptoJS.enc.Utf8.parse("nothing");
//     const hashedKey = CryptoJS.SHA256(key)
//   ; // Hash the key to get a 256-bit key
  
//     // Generate random IV (16 bytes for AES-256-CBC)
//     const iv = CryptoJS.lib.WordArray.random(16);
  
//     const encrypted = CryptoJS.AES.encrypt(
//       CryptoJS.enc.Utf8.parse(pwd),
//       hashedKey,
//       {
//         iv: iv,
//         mode: CryptoJS.mode.CBC,
//         padding: CryptoJS.pad.Pkcs7,
//       }
//     );
  
//     // Prepend the IV to the encrypted ciphertext for passing it along with the encrypted password
//     const encryptedPayload =
//       iv.toString(CryptoJS.enc.Base64) + ":" + encrypted.toString();
  
//     return encryptedPayload;
//   };

// export default encryptData