import { Router } from "express";
import { deleteAccount, getUsers, loginUser, registerUser, updatePassword } from "../controllers/user.controllers.js";

const router = Router()

router.route("/register").post(registerUser)

router.route("/getUsers").get(getUsers)

router.route("/login").post(loginUser)

router.route("/updatePassword").post(updatePassword)

router.route("/deleteAccount").post(deleteAccount)

export default router