import { Router } from "express";
import { addMovies, getMovies, getUsersFromMovie, insertManyMovies } from "../controllers/movies.controllers.js";

const router = Router()

router.route("/addMovies").post(addMovies)

router.route("/getMovies").post(getMovies)

router.route("/getUsersFromMovie").post(getUsersFromMovie)

router.route("/insertManyMovies").post(insertManyMovies)


export default router