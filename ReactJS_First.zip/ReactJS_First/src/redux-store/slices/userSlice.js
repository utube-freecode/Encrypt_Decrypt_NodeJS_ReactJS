import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    isLoading : false,
    userData : null
}

const userSlice = createSlice({
    name : 'userSlice',
    initialState,
    reducers : {
        isLoadingReducer : (state, action) => {
            return{
                ...state,
                isLoading : action.payload
            }
        },
        userReducer : (state, action) => {
            return {
                ...state,
                userData : action.payload
            }
        }
    }
})

export const {isLoadingReducer, userReducer} = userSlice.actions

export default userSlice.reducer