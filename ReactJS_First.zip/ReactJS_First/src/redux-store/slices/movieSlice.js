import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    isLoading : false,
    movieData : null
}

const movieSlice = createSlice({
    name : 'movieSlice',
    initialState,
    reducers : {
        isLoadingMovieReducer : (state, action) => {
            return{
                ...state,
                isLoading : action.payload
            }
        },
        movieReducer : (state, action) => {
            return {
                ...state,
                movieData : action.payload
            }
        }
    }
})

export const {isLoadingMovieReducer, movieReducer} = movieSlice.actions

export default movieSlice.reducer