import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'      // react-router-dom
import { Home, Login, Movies, Register } from './pages/index.js'


import { Provider } from 'react-redux'            // react-redux
import store from './redux-store/store.js'



// router
const router = createBrowserRouter([
  {
    path : "/",
    element : <App />,
    children : [
      {
        path : '/',
        element : <Login />
      },
      {
        path : '/register',
        element : <Register />
      },
      {
        path : '/home',
        element : <Home />
      },
      {
        path : '/movies',
        element : <Movies />
      }
    ]
  }
])


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Provider store={store}>
      <RouterProvider router={router}/>
    </Provider>
  </StrictMode>,
)
