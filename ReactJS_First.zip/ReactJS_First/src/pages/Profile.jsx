

function Profile() {

    return (
      <>
        <h2>Profile</h2>
      </>
    )
  }
  
  export default Profile
  