import { useDispatch, useSelector } from "react-redux"
import { isLoadingMovieReducer, movieReducer } from "../redux-store/slices/movieSlice"
import axios from "axios"
import { useEffect, useState } from "react"
import decryptData from "../functions/decryptData"
import encryptData from "../functions/encryptData"



function Movies() {

    const dispatch = useDispatch()              // useDispatch
    const isLoading = useSelector((state) => state?.movieSlice?.isLoading)       // useSelector
    console.log(isLoading, "isLoading")

    const userSelector = useSelector(state => state?.userSlice?.userData)
    console.log(userSelector, "userSelector")

    // const [user, setUser] = useState()            // useState
    // console.log(user, "user")

    const movies = useSelector(state => state?.movieSlice?.movieData)
    console.log(movies, "movies")


    // useEffect
    useEffect(() => {
      //decryptUser()       // Calling Function
      handleMovies()      // Calling Function
    },[])


    // decryptUser
    // const decryptUser = () => {
    //   if(userSelector){
    //     const decrypted = decryptData(userSelector)
    //     console.log(decrypted, "decrypted")
    //     if(decrypted){
    //       setUser({decrypted})
    //     }
    //   }
    // }

    // useEffect
    // useEffect(() => {
    //   if(user){
    //     handleMovies()        // Calling Function
    //   }
    // },[user])



    // handleMovies
    const handleMovies = async() => {
      console.log("handleMoviesCalled")
      try {
        dispatch(isLoadingMovieReducer(true))

        // const cipherData = await encryptData(user)
        // console.log(cipherData, "cipherData")

        const respone = await axios.post("http://localhost:8000/movies/getMovies", {
          cipherData : userSelector
        },{
          headers : {
            "Content-Type" : "application/json"
          }
        })

        console.log(respone, "response")

        const decryptedMovies = decryptData(respone?.data?.data)
        console.log(decryptedMovies, "decryptedMovies")

        dispatch(movieReducer(decryptedMovies))
        dispatch(isLoadingMovieReducer(false))
        
      } catch (error) {
        console.log(error, "handleMoviesError")
        dispatch(isLoadingMovieReducer(false))
      }
    }

    return isLoading ? <h2>Loading...</h2> : (
      <>
        <h2 className="text-primary">Movies</h2>

        {movies && movies?.map((item) => {
          return(
            <>
              <p>{item?.movieName}</p>
            </>
          )
        })}

      </>
    )
  }
  
  export default Movies
  