import { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { NavLink } from "react-router-dom"
import decryptData from "../functions/decryptData"


function Home() {

    const userSelector = useSelector(state => state?.userSlice?.userData)
    console.log(userSelector, "userSelector")

    const [user, setUser] = useState()              // useState


    // useEffect
    useEffect(() => {
      decryptUser()         // Calling Function
    },[])


    // decryptUser
    const decryptUser = () => {
      if(userSelector){
        const decrypted = decryptData(userSelector)
        if(decrypted){
          setUser(decrypted?.fullName)
        }
      }
    }

    return (
      <>
        <h3>Home</h3>

        <h4 className="text-primary">Welcome - {user}</h4>

        <NavLink to={'/movies'} >Movies</NavLink>
      </>
    )
  }
  
  export default Home
  