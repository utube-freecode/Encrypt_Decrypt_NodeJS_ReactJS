import Login from "./Login";
import Home from './Home';
import Register from "./Register";
import AddMovies from './AddMovies';
import Movies from './Movies'
import Profile from './Profile'


export {Login, Home, Register, AddMovies, Movies, Profile}