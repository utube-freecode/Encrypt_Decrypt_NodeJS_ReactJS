import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import { useNavigate } from "react-router-dom"
import { useDispatch, useSelector } from "react-redux"
import { useForm } from "react-hook-form"
import axios from "axios";
import { isLoadingReducer } from "../redux-store/slices/userSlice";


function Register() {

    const navigate = useNavigate()              // useNavigate

    const dispatch = useDispatch()              // useDispatch
    const isLoading = useSelector((state) => state?.userSlice?.isLoading)       // useSelector
    console.log(isLoading, "isLoading")

    const {handleSubmit, reset, formState, register, watch} = useForm({
        mode : 'onBlur'
    })         // useForm
    const {errors, isSubmitSuccessful} = formState      // formState


    // handleLogin
    const handleRegister = async(data) => {
        console.log(data, "RegisterFormData")

        try {
            dispatch(isLoadingReducer(true))
            const response = await axios.post("http://localhost:8000/user/register", {
                username : data?.username,
                email : data?.email,
                fullName : data?.fullName,
                password : data?.password
            })

            console.log(response, "RegisterResponse")
            dispatch(isLoadingReducer(false))
            navigate('/')
        } catch (error) {
            console.log(error)
            dispatch(isLoadingReducer(false))
        }

    }

  return (
    <>
      <h2>Register</h2>

      <form onSubmit={handleSubmit(handleRegister)}>
        <div className="form-group">
            <label htmlFor="username">Username : </label>
                <input name="username" placeholder="Enter username" className="form-control" type="text" 
                    {...register("username", {
                        required : {
                            value : true,
                            message : 'Username is required'
                        }
                    })}
                />
            {errors && <p className="form-text text-danger">{errors?.username?.message}</p>}
        </div>
        
        <div className="form-group">
            <label htmlFor="username">Email : </label>
                <input name="email" placeholder="Enter email" className="form-control" type="email" 
                    {...register("email", {
                        required : {
                            value : true,
                            message : 'Email is required'
                        }
                    })}
                />
                {errors && <p className="form-text text-danger">{errors?.email?.message}</p>}
        </div>

        <div className="form-group">
            <label htmlFor="fullName">Full Name : </label>
                <input name="fullName" placeholder="Enter full name" className="form-control" type="text" 
                    {...register("fullName", {
                        required : {
                            value : true,
                            message : 'Full name is required'
                        }
                    })}
                />
                {errors && <p className="form-text text-danger">{errors?.fullName?.message}</p>}
        </div>

        <div className="form-group">
            <label htmlFor="password">Password</label>
                <input name="password" placeholder="Enter password" className="form-control" type="password" 
                    {...register("password", {
                        required : {
                            value : true,
                            message : 'Password is required'
                        }
                    })}
                />
                {errors && <p className="form-text text-danger">{errors?.password?.message}</p>}
        </div>

        <button type="submit" className="btn btn-primary">Register</button>

      </form>

        
    </>
  )
}

export default Register
