import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import { useNavigate } from "react-router-dom"
import { useDispatch, useSelector } from "react-redux"
import { useForm } from "react-hook-form"
import axios from "axios";
import { isLoadingReducer, userReducer } from "../redux-store/slices/userSlice";
import * as jose from 'jose'
import encryptData from "../functions/encryptData";
import decryptData from "../functions/decryptData";



function Login() {

    const navigate = useNavigate()              // useNavigate

    const dispatch = useDispatch()              // useDispatch
    const isLoading = useSelector((state) => state?.userSlice?.isLoading)       // useSelector
    console.log(isLoading, "isLoading")

    const {handleSubmit, reset, formState, register, watch} = useForm({
        mode : 'onBlur'
    })         // useForm
    const {errors, isSubmitSuccessful} = formState      // formState


    // handleLogin
    const handleLogin = async(data) => {
        console.log(data, "LoginFormData")

        // const cipherData = encryptData({
        //     username : data?.username,
        //     password : data?.password
        // })

        const str = JSON.stringify(data)
        console.log(str, "str")

        try {
            dispatch(isLoadingReducer(true))

            const cipherData = await encryptData(str)
            console.log(cipherData, "cipherData")


            const response = await axios.post(String(import.meta.env.VITE_API_URL) + "/user/login", {
                cipherData :  cipherData
            }, {
                headers : {
                    "Content-Type" : "application/json"
                }
            })

            console.log(response, "LoginResponse")
            dispatch(isLoadingReducer(false))

            const decrypted = decryptData(response?.data?.data)
            console.log(decrypted, "decrypted")

            dispatch(userReducer(response?.data?.data))
            navigate('/home')
        } catch (error) {
            console.log(error)
            dispatch(isLoadingReducer(false))
        }

    }

  return isLoading ? <h1>Loading...</h1> : (
    <>
      <h2>Login</h2>

      <form onSubmit={handleSubmit(handleLogin)}>
        <div className="form-group">
            <label htmlFor="username">Username : </label>
                <input name="username" placeholder="Enter username" className="form-control" type="text" 
                    {...register("username", {
                        required : {
                            value : true,
                            message : 'Username is required'
                        }
                    })}
                />
            {errors && <p className="form-text text-danger">{errors?.username?.message}</p>}
        </div>
        

        <div className="form-group">
            <label htmlFor="password">Password</label>
                <input name="password" placeholder="Enter password" className="form-control" type="password" 
                    {...register("password", {
                        required : {
                            value : true,
                            message : 'Password is required'
                        }
                    })}
                />
                {errors && <p className="form-text text-danger">{errors?.password?.message}</p>}
        </div>

        <button type="submit" className="btn btn-primary">Login</button>

      </form>

        
    </>
  )
}

export default Login
