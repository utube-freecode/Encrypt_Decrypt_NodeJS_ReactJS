

function AddMovies() {

    return (
      <>
        <h2>Add Movies</h2>
      </>
    )
  }
  
  export default AddMovies
  